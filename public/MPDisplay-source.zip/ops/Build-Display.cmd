@echo off
setlocal
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars32.bat" >nul
if errorlevel 1 exit /b 1
cd /d "%~dp0..\client-display"
if not exist "..\tools\Detours\lib.X86\detours.lib" (
 pushd "..\tools\Detours\src"
 nmake /nologo
 if errorlevel 1 exit /b 1
 popd
)
cl /nologo /LD /MT /EHsc /O2 /std:c++17 /utf-8 /DMP_HUD_EXPERIMENTAL /DMP_STAGE_RESOLUTION Display.cpp HudAssets.cpp /link /OUT:dinput8.dll /DEF:Display.def /OPT:REF user32.lib ..\tools\Detours\lib.X86\detours.lib
exit /b %errorlevel%
