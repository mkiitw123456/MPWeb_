@echo off
setlocal
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars32.bat" >nul
if errorlevel 1 exit /b 1
cd /d "%~dp0..\client-display"
cl /nologo /LD /MT /EHsc /O2 /std:c++17 /utf-8 Display.cpp /link /OUT:dinput8.dll /DEF:Display.def /OPT:REF user32.lib
exit /b %errorlevel%
