#include <windows.h>
#include <cstring>
#include <cstdio>
#include "../tools/Detours/src/detours.h"
using Getter=void*(__fastcall*)(void*,void*,void*,unsigned int,char);
using Assign=void(__thiscall*)(void*,const char*,int);
static Getter getString=reinterpret_cast<Getter>(0x0079E993);
static auto assign=reinterpret_cast<Assign>(0x00414617);
static int hudWidth=800;
static void* __fastcall asset(void* self,void* unused,void* result,unsigned int id,char formal){
 void* ret=getString(self,unused,result,id,formal);if(!ret)return ret;
 const char* source=*reinterpret_cast<const char**>(ret);if(!source)return ret;
 #ifdef MP_HUD_TRACE
 if(std::strstr(source,"StatusBar.img")){static bool seen[8192]={};if(id<8192&&!seen[id]){seen[id]=true;FILE* log=nullptr;fopen_s(&log,"hud-resources.txt","a");if(log){fprintf(log,"%u %s\n",id,source);fclose(log);}}}
 #endif
 const char* path=source;bool prefix=std::strncmp(path,"UI/",3)==0;if(prefix)path+=3;
 const char* target=nullptr;
 if(!std::strcmp(path,"StatusBar.img"))target="status";
 if(!std::strcmp(path,"StatusBar.img/base/chat"))target="chat";
 if(hudWidth>=960){
  if(!std::strcmp(path,"StatusBar.img/gauge/bar"))target="bar";
  if(!std::strcmp(path,"StatusBar.img/gauge/graduation"))target="graduation";
  if(!std::strcmp(path,"StatusBar.img/gauge/hpFlash/0"))target="hpFlash0";
  if(!std::strcmp(path,"StatusBar.img/gauge/hpFlash/1"))target="hpFlash1";
  if(!std::strcmp(path,"StatusBar.img/gauge/mpFlash/0"))target="mpFlash0";
  if(!std::strcmp(path,"StatusBar.img/gauge/mpFlash/1"))target="mpFlash1";
 }
 if(target){char name[128];sprintf_s(name,"%sMPHudProfiles.img/w%d/%s",prefix?"UI/":"",hudWidth,target);assign(ret,name,-1);}
 return ret;
}
bool InitHudAssets(int width){
 const BYTE expected[]={0xb8,0xa2,0x70,0xab,0x00};
 if(memcmp((void*)0x0079E993,expected,sizeof(expected)))return false;
 hudWidth=width;
 if(DetourTransactionBegin()!=NO_ERROR)return false;
 if(DetourUpdateThread(GetCurrentThread())!=NO_ERROR||DetourAttach(reinterpret_cast<PVOID*>(&getString),asset)!=NO_ERROR){DetourTransactionAbort();return false;}
 return DetourTransactionCommit()==NO_ERROR;
}
