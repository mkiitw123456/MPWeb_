# MPDisplay source

GMS v83 display adaptation, derived from MapleEzorsia-v2 under AGPL-3.0.
See LICENSE and UPSTREAM.json. Microsoft Detours is included under MIT.

Build on Windows with Visual Studio 2022 Community C++ tools / x86 SDK:

```
ops\Build-Display.cmd
```

The script builds Detours if needed, then creates client-display/dinput8.dll.
The game imports this library as mpinput.dll; release packaging renames it.
Always deploy it together with the matching UI.wz HUD profiles.
The source archive excludes game executables and WZ archives.

The supported executable is the frozen v83 client checked by Display.cpp.
Login and character selection use 800x600. StageResolution.inc switches code
operands, the backbuffer, and UI origin before game UI creation on entry and
after game UI teardown on exit. A monitor-sized game uses a borderless window to keep
the bottom status bar visible; returning to login restores the normal frame.

WideLayout.inc, GaugeAnchors.inc and GaugeSizing.inc adjust layout and fill
calculations. HudAssets.cpp selects matching images via the string pool.
The persistent notice window is allocated at the configured width from startup;
both its scrolling distance and duration include the expanded viewport width.
MP_HUD_EXPERIMENTAL is a retained build flag name; the release build enables it
together with MP_STAGE_RESOLUTION. Do not disable one without matching assets.

Runtime validation covers 1280x720 Chinese UI and 1920x1080 English UI on the
development machine. This is not a guarantee for every GPU or map.
