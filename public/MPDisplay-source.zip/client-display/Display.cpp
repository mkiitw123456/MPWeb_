#include <windows.h>
#include <cmath>
#include <vector>
#include <cstring>
#include <stdexcept>
class Client {public:static int m_nGameWidth,m_nGameHeight,MsgAmount;static bool WindowedMode,RemoveLogos;static void UpdateResolution();};
int Client::m_nGameWidth=800,Client::m_nGameHeight=600,Client::MsgAmount=6;
bool Client::WindowedMode=true,Client::RemoveLogos=false;
class MainMain {public:static constexpr bool CustomLoginFrame=false,bigLoginFrame=false;};
struct Edit {DWORD address;std::vector<unsigned char> bytes;};
static std::vector<Edit> edits;
class Memory {public:
 static void WriteByteArray(DWORD a,const unsigned char* b,int n){if(a<0x401000||a+n>0xc00000||n<=0||n>256)throw std::runtime_error("Invalid display patch");edits.push_back({a,{b,b+n}});}
 static void WriteInt(DWORD a,unsigned int v){WriteByteArray(a,(unsigned char*)&v,4);}
 static void WriteByte(DWORD a,unsigned char v){WriteByteArray(a,&v,1);}
 static void FillBytes(DWORD a,unsigned char v,int n){std::vector<unsigned char> b(n,v);WriteByteArray(a,b.data(),n);}
 static void CodeCave(void* f,DWORD a,int n){if(n<5)throw std::runtime_error("Invalid jump");FillBytes(a,0x90,n);WriteByte(a,0xe9);WriteInt(a+1,(DWORD)f-a-5);}
};
#include "AddyLocations.h"
#include "codecaves.h"
#include "Resolution.inc"
extern "C" __declspec(dllexport) void InitDisplay() {}
extern "C" HRESULT WINAPI DirectInput8Create(HINSTANCE instance,DWORD version,REFIID iid,LPVOID* output,LPUNKNOWN outer) {
 static HMODULE real=[](){wchar_t path[MAX_PATH];GetSystemDirectoryW(path,MAX_PATH);wcscat_s(path,L"\\dinput8.dll");return LoadLibraryW(path);}();
 if(!real)return HRESULT_FROM_WIN32(GetLastError());
 auto create=(HRESULT(WINAPI*)(HINSTANCE,DWORD,REFIID,LPVOID*,LPUNKNOWN))GetProcAddress(real,"DirectInput8Create");
 HRESULT result=create?create(instance,version,iid,output,outer):E_FAIL;
 wchar_t file[MAX_PATH];GetModuleFileNameW(nullptr,file,MAX_PATH);auto slash=wcsrchr(file,L'\\');if(slash){wcscpy_s(slash+1,MAX_PATH-(slash+1-file),L"mp-display-diagnostic.txt");HANDLE log=CreateFileW(file,FILE_APPEND_DATA,FILE_SHARE_READ,nullptr,OPEN_ALWAYS,0,nullptr);if(log!=INVALID_HANDLE_VALUE){char line[128];int n=sprintf_s(line,"DirectInput8Create version=%lu result=%08lx\r\n",version,result);DWORD count;WriteFile(log,line,n,&count,nullptr);CloseHandle(log);}}
 return result;
}
BOOL WINAPI DllMain(HINSTANCE module,DWORD reason,LPVOID) {
 if(reason!=DLL_PROCESS_ATTACH)return TRUE;
 DisableThreadLibraryCalls(module);
 wchar_t path[MAX_PATH];GetModuleFileNameW(module,path,MAX_PATH);auto slash=wcsrchr(path,L'\\');if(!slash)return FALSE;wcscpy_s(slash+1,MAX_PATH-(slash+1-path),L"mp-display.ini");
 int width=GetPrivateProfileIntW(L"Display",L"Width",800,path),height=GetPrivateProfileIntW(L"Display",L"Height",600,path);
 if(width<800||height<600||width>2560||height>1440||width%2||height%2)return FALSE;
 if((DWORD)GetModuleHandleW(nullptr)!=0x400000||memcmp((void*)0x44ec9c,"\x31\xc0\xc3",3)||*(BYTE*)0x9f7b1d!=0x68||*(DWORD*)0x9f7b1e!=600||*(DWORD*)0x9f7b24!=800)return FALSE;
 try {
  if(width!=800||height!=600){Client::m_nGameWidth=width;Client::m_nGameHeight=height;Client::UpdateResolution();}
  // The shared 2560x1440 frame has an 800x600 transparent center at (880,420).
  // v83 positions this canvas explicitly and does not use its WZ origin property.
  Memory::WriteInt(0x005F481F,-720);Memory::WriteInt(0x005F4825,-1280);
  for(auto& e:edits){DWORD old;if(!VirtualProtect((void*)e.address,e.bytes.size(),PAGE_EXECUTE_READWRITE,&old))return FALSE;memcpy((void*)e.address,e.bytes.data(),e.bytes.size());DWORD ignored;VirtualProtect((void*)e.address,e.bytes.size(),old,&ignored);}
  FlushInstructionCache(GetCurrentProcess(),nullptr,0);
 }catch(...){return FALSE;}
 return TRUE;
}
